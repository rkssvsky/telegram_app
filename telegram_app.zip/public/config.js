const api = {
  REST_API: true,
  REST_API_SVC: 'https://api.yurichain-testnet.ru',
  EXPLORER_URL: 'http://172.22.101.6:8088'
}
window.api = api
