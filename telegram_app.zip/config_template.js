const api = {
  REST_API: true,
  REST_API_SVC: '${gateway_svc_addr}',
  USERS_SVC: '${users_svc_addr}',
  EXPLORER_URL: '${explorer_url}',
  RENTAL_SVC: '${rentals_svc_addr}',
  OBJECTS_SVC: '${objects_svc_addr}',
  WALLET_SVC: '${wallets_svc_addr}'
}
window.api = api
