<template>
  <v-container>
    <div class="align-center">
      У вас нет завершенных розыгрышей <br />
      <v-btn rounded="lg">Создать</v-btn>
    </div>
  </v-container>
</template>

<script setup></script>
